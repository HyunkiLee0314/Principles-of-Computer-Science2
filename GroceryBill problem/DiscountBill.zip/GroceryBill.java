

public class GroceryBill{

   public GroceryBill(String clerk){
   
   }
   
   public void add(Item i){
   
   
      }
   
   public double getTotal(){
      
      return 0;
   }
   
   public void printReceipt(){
   
   }
}